//
//  MenuCategory.swift
//  LittleLemonMenu
//
//  Created by russell price on 4/16/23.
//

import Foundation

enum Categories: String {
    case food = "Food"
    case drinks = "Drinks"
    case desserts = "Desserts"
}
 
let category = Categories.food
